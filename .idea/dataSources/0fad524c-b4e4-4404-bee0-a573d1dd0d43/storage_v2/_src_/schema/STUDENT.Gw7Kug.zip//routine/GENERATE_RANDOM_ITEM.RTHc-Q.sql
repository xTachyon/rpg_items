create procedure generate_random_item(p_owner_id in rpg_characters.character_id%type) as
  p_base_level rpg_items.base_level%type;
  p_item_type rpg_items.ITEM_TYPE%type;
  p_item_rarity rpg_items.ITEM_RARITY%type;
  p_item_magic_type rpg_items.ITEM_MAGIC_TYPE%type;
  p_expiration_date rpg_items.EXPIRATION_DATE%type;
  p_durability rpg_items.MAXIMUM_DURABILITY%type;
  p_stat_num rpg_item_rarity.STATS_NUMBER%type;
begin
  -- item data without the stats
  p_base_level := trunc(DBMS_RANDOM.value(1,101));
  p_item_type := trunc(DBMS_RANDOM.value(1, rpg_item_types_seq.currval + 1));
  p_item_rarity := trunc(DBMS_RANDOM.value(1, rpg_item_rarity_seq.currval + 1));
  p_item_magic_type := trunc(DBMS_RANDOM.value(1, rpg_magic_types_seq.currval + 1));
  if ( DBMS_RANDOM.value(0,1) <= 0.1 ) then
    p_expiration_date := sysdate + trunc(DBMS_RANDOM.value(1,31));
  else
    p_expiration_date := null;
  end if;
  p_durability := 10 * (p_base_level + trunc(DBMS_RANDOM.value(1,10)));

  insert into RPG_ITEMS values (rpg_items_seq.nextval,p_owner_id,p_base_level,p_durability,p_durability,p_expiration_date,p_item_type,
                                p_item_rarity,p_item_magic_type,0);
  -- item stats
  select STATS_NUMBER into p_stat_num from RPG_ITEM_RARITY where p_item_rarity = RARITY_ID;
--   for i in 0..p_stat_num loop
--     generate_random_item_stat(rpg_items_seq.currval, p_item_type);
--   end loop;
end;
/

