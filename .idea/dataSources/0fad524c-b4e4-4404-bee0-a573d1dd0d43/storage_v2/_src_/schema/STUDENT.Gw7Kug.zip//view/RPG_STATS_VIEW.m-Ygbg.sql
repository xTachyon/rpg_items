create view RPG_STATS_VIEW as
select item_id, name, utility_name, rpg_item_stats.value
from rpg_item_stats join rpg_stat_types on rpg_item_stats.type_id = rpg_stat_types.type_id
  join rpg_item_utilities on rpg_stat_types.utility_id = rpg_item_utilities.utility_id
/

