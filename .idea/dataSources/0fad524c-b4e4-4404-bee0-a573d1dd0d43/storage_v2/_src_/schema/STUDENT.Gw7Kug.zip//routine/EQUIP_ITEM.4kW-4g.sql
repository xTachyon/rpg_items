create procedure equip_item(in_character_id in rpg_items.owner_id%type, in_item_id in rpg_items.item_id%type) is
  equip_type varchar2(20) := get_equip_type(in_item_id);
  equiped_item_id rpg_items.owner_id%type;
  character_lvl number;
  item_lvl number;
begin
  select CHARACTER_LEVEL into character_lvl from RPG_CHARACTERS where CHARACTER_ID = in_character_id;
  select BASE_LEVEL into item_lvl from RPG_ITEMS where ITEM_ID = in_item_id;
  if(character_lvl < item_lvl) then
    raise_application_error(-20004,'Ai nivel prea mic pentru a folosi acest item ');
  end if;
  select ITEM_ID into equiped_item_id from RPG_ITEMS
  where get_equip_type(item_id) = equip_type and IS_EQUIPPED = 1 and OWNER_ID = in_character_id;
  update RPG_ITEMS set IS_EQUIPPED = 0 where ITEM_ID = equiped_item_id;
  update RPG_ITEMS set IS_EQUIPPED = 1 where ITEM_ID = in_item_id;
  exception when no_data_found then
    update RPG_ITEMS set IS_EQUIPPED = 1 where ITEM_ID = in_item_id;
end;
/

