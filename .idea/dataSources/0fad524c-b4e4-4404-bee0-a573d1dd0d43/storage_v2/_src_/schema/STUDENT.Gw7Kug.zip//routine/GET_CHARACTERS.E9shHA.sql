create procedure get_characters(in_user_id in rpg_users.USER_ID%type, out_characters out character_list) as
  begin
    select character_list_record(CHARACTER_ID, name, floor(CHARACTER_LEVEL), trim(nvl(to_char(ceil(trunc(DELETED_AT + 3) - sysdate)),'inf')))
      bulk collect into out_characters
    from RPG_CHARACTERS c join RPG_USERS u on u.USER_ID = c.USER_ID
    where u.USER_ID = in_user_id;
  end;
/

