create procedure sell_item(in_item_id in rpg_items.item_id%type) is
  owner_id number;
  v_price number;
  item_rarity number;
  item_level number;
  item_durability_procentage number;
  item_days_util_expiration number;
begin
  select owner_id,RARITY_ID,base_level,current_durability/maximum_durability, nvl(ceil(trunc(expiration_date) - sysdate) + 1, 100)
  INTO owner_id,item_rarity,item_level,item_durability_procentage,item_days_util_expiration
  from rpg_items join rpg_item_types on rpg_items.item_type = rpg_item_types.type_id
    join rpg_item_utilities on rpg_item_types.utility_id = rpg_item_utilities.utility_id
    join rpg_item_rarity on rpg_items.item_rarity = rpg_item_rarity.rarity_id
    join rpg_magic_types on rpg_items.item_magic_type = rpg_magic_types.magic_id
  where in_item_id = RPG_ITEMS.ITEM_ID;
  v_price := item_rarity*(item_level + item_days_util_expiration)*item_durability_procentage;
  DBMS_OUTPUT.PUT_LINE(v_price);
  update rpg_characters set GOLD = GOLD + v_price where owner_id = CHARACTER_ID;
  delete from RPG_ITEMS where in_item_id = ITEM_ID;
end;
/

