create trigger ON_ITEM_DELETE
  before delete
  on RPG_ITEMS
  for each row
begin
    delete from RPG_ITEM_STATS where RPG_ITEM_STATS.ITEM_ID = :OLD.item_id;
  end;
/

