create function user_login(in_username in rpg_users.username%type, in_password in rpg_users.password%type)
return rpg_users.user_id%type is
  v_user_id rpg_users.user_id%type;
  counter number;
  mesaj varchar2(100);
begin
  select USER_ID into v_user_id
  from RPG_USERS
  where in_username = USERNAME and in_password = PASSWORD;
  return v_user_id;
  exception
  when no_data_found then
    SELECT COUNT(*) INTO counter FROM RPG_USERS WHERE USERNAME = in_username;
    IF counter = 0 THEN
      mesaj   := 'Utilizatorul ' || in_username || ' nu exista.';
    ELSE
      mesaj   := 'Parola gresita pentru utilizatorul ' || in_username || '.';
    END IF;
    raise_application_error (-20001, mesaj);
end;
/

