create function get_equip_type(in_item_id in rpg_items.item_id%type)
return varchar2 is
  type_name varchar2(20);
  utility_name varchar2(20);
begin
  select TYPE_NAME,UTILITY_NAME into type_name, utility_name from RPG_ITEMS_VIEW where in_item_id = ITEM_ID;
  if(lower(utility_name) = 'attack') then
    return lower(utility_name);
  else
    return lower(type_name);
  end if;
end;
/

