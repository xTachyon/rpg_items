create view RPG_ITEMS_VIEW as
select item_id,owner_id,base_level,current_durability,maximum_durability,expiration_date,type_name,utility_name,rarity_name,rarity_color,magic_name
from rpg_items join rpg_item_types on rpg_items.item_type = rpg_item_types.type_id
  join rpg_item_utilities on rpg_item_types.utility_id = rpg_item_utilities.utility_id
  join rpg_item_rarity on rpg_items.item_rarity = rpg_item_rarity.rarity_id
  join rpg_magic_types on rpg_items.item_magic_type = rpg_magic_types.magic_id
/

