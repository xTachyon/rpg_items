create procedure delete_characters_job as
  begin
    delete from RPG_items where EXPIRATION_DATE is not null and EXPIRATION_DATE < sysdate;
  end;
/

