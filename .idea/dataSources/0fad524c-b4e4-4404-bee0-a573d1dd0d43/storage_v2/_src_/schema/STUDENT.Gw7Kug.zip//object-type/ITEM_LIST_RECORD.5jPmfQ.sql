create type item_list_record is object (
  item_id number,
  item_level number,
  item_durability varchar(10),
  item_expiration_date varchar2(20),
  item_name varchar2(100),
  item_rarity varchar2(100),
  item_magic varchar2(100),
  item_stats_string varchar2(2000)
)
/

