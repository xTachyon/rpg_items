create procedure generate_friendships is
  id1 number;
  id2 number;
  friends_already number;
  countt number;
BEGIN
  select count(*)
  into countt
  from RPG_USERS;

  loop
    id1 := trunc(DBMS_RANDOM.value(0, countt)) + 1;
    id2 := trunc(DBMS_RANDOM.value(0, countt)) + 1;

    exit when id1 <> id2;
  end loop;

  select count(*)
  into friends_already
  from RPG_FRIENDS
  where (USER_ID1 = id1 and USER_ID2 = id2) or (USER_ID1 = id2 and USER_ID2 = id1);

  if friends_already = 0 then
    insert into RPG_FRIENDS
    values (rpg_friends_seq.nextval, id1, id2);
  end if;
END;
/

