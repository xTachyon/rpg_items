create procedure buy_item(in_character_id in rpg_items.OWNER_ID%type,in_rarity_name in rpg_item_rarity.rarity_name%type) is
  -- for item initialisation
  p_base_level rpg_items.base_level%type;
  p_item_type rpg_items.ITEM_TYPE%type;
  p_item_rarity rpg_items.ITEM_RARITY%type;
  p_item_magic_type rpg_items.ITEM_MAGIC_TYPE%type;
  p_expiration_date rpg_items.EXPIRATION_DATE%type;
  p_durability rpg_items.MAXIMUM_DURABILITY%type;
  p_stat_num rpg_item_rarity.STATS_NUMBER%type;

  -- for stats initialisation
  type arr_stat_types is table of rpg_stat_types.TYPE_ID%type;

  stat_types arr_stat_types;

  p_item_utility number;
  p_any_utility number;
  p_num_options number;
  p_option number;

  p_min number;
  p_max number;
  p_type_name varchar2(200);

  p_price number;
  p_owner_gold number;
begin
  -- verificam daca userul are destui bani
    select GOLD, CHARACTER_LEVEL into p_owner_gold, p_base_level
    from RPG_CHARACTERS where character_id = in_character_id;
    select RARITY_ID into p_item_rarity from RPG_ITEM_RARITY where lower(RARITY_NAME) = lower(in_rarity_name);
    p_price := p_item_rarity*(p_base_level + 100);
    if(p_price > p_owner_gold) then
      raise_application_error(-20006,'Nu aveti '|| p_price ||' gold');
    else
      update RPG_CHARACTERS set GOLD = GOLD - p_price where in_character_id = CHARACTER_ID;
    end if;
  -- random item data without the stats
  p_base_level := trunc(DBMS_RANDOM.value(p_base_level,101));
  p_item_type := trunc(DBMS_RANDOM.value(1, 18));
  p_item_rarity := trunc(DBMS_RANDOM.value(p_item_rarity, 5));
  p_item_magic_type := trunc(DBMS_RANDOM.value(1, 6));
  if ( DBMS_RANDOM.value(0,1) <= 0.9 ) then
    p_expiration_date := sysdate + trunc(DBMS_RANDOM.value(1,31));
  else
    p_expiration_date := null;
  end if;
  p_durability := 10 * (p_base_level + trunc(DBMS_RANDOM.value(1,10)));

  insert into RPG_ITEMS values (rpg_items_seq.nextval,in_character_id,p_base_level,p_durability,p_durability,p_expiration_date,p_item_type,
                                p_item_rarity,p_item_magic_type,0);
  -- random item stats

  select UTILITY_ID into p_item_utility from RPG_ITEM_TYPES where p_item_type = TYPE_ID;
  select UTILITY_ID into p_any_utility from RPG_ITEM_UTILITIES where UTILITY_NAME = 'any';
  if ( p_item_utility = p_any_utility) then
    select TYPE_ID
    bulk collect into stat_types
    from RPG_STAT_TYPES;
  else
    select TYPE_ID
    bulk collect into stat_types
    from RPG_STAT_TYPES
    where p_item_utility = UTILITY_ID;
  end if;

  select STATS_NUMBER into p_stat_num from RPG_ITEM_RARITY where p_item_rarity = RARITY_ID;

  p_num_options := stat_types.COUNT;
  for i in 0..p_stat_num loop
    p_option := trunc(DBMS_RANDOM.value(1, p_num_options + 1));
    loop
      p_option := mod(p_option + 1, p_num_options + 1);
      if p_option = 0 then
        p_option := 1;
      end if;
      exit when stat_types.exists(p_option);
    end loop;

    select MIN_BASE_VALUE, MAX_BASE_VALUE, NAME into p_min , p_max, p_type_name
    from RPG_STAT_TYPES
    where p_option = TYPE_ID;

    if p_type_name in ('attack damage', 'critical damage', 'armor breaking damage', 'armor','health') then
      insert into rpg_item_stats values (rpg_items_seq.currval,p_option,p_base_level*round(DBMS_RANDOM.value(p_min,p_max),2));
    else
      insert into rpg_item_stats values (rpg_items_seq.currval,p_option,round(DBMS_RANDOM.value(p_min,p_max),2));
    end if;

    stat_types.delete(p_option);
  end loop;
  exception when no_data_found then
    p_num_options :=0;
    select count(*) into p_num_options from RPG_ITEM_RARITY where lower(RARITY_NAME) = lower(in_rarity_name);
    if(p_num_options = 0) then
      raise_application_error(-20007, 'Poti introduce ca raritate dorita doar: \"common\", \"rare\", \"epic\", \"legendary\"');
    else
      raise no_data_found ;
    end if;
end;
/

