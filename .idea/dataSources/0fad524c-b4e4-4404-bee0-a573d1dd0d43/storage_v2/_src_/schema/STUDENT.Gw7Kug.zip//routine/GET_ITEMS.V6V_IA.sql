create procedure get_items(in_character_id in rpg_items.owner_id%type, out_item_list out item_list, in_is_equiped in number) is
begin
  select item_list_record( ITEM_ID, BASE_LEVEL, CURRENT_DURABILITY || '/' || MAXIMUM_DURABILITY,
         nvl(to_char(EXPIRATION_DATE,'DD-MM-YYYY'),'never'),TYPE_NAME,RARITY_NAME,MAGIC_NAME, item_stats_to_string(ITEM_ID))
    bulk collect into out_item_list
  from RPG_ITEMS_VIEW
  where OWNER_ID =  in_character_id and IS_EQUIPPED = in_is_equiped;
end;
/

