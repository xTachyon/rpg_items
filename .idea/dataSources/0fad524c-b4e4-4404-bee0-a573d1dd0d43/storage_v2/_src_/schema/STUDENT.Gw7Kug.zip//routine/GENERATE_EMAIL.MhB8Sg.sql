create function generate_email return varchar2 as
  names_list arr_varchar2 := arr_varchar2('andrei', 'mihai', 'matei');
  providers_list arr_varchar2 := arr_varchar2('gmail', 'yahoo');

  result varchar2(200);
  r number;
  r2 number;
  r3 number;
BEGIN
  r := DBMS_RANDOM.value(1, names_list.COUNT);
  r2 := DBMS_RANDOM.value(1, names_list.COUNT);
  r3 := DBMS_RANDOM.value(1, providers_list.COUNT);

--   result := names_list(r) || '_' || names_list(r2) || '@' || providers_list(r3) || '.com';
  result := generate_random_string(DBMS_RANDOM.value(5, 20)) || '_' || names_list(r2) || '@' || providers_list(r3) || '.com';


  return result;
END;
/

