create view RPG_FRIENDS_VIEW as
select ru1.user_id as "User_ID1",ru1.username as "User1", ru2.user_id as "User_ID2", ru2.username as "User2"
from rpg_users ru1 join rpg_friends rf on ru1.user_id = rf.user_id1
  join rpg_users ru2 on ru2.user_id = rf.user_id2
/

