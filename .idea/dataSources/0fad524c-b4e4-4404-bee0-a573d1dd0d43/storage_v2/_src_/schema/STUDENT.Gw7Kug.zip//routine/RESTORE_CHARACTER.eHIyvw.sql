create procedure restore_character(in_character_id in rpg_characters.CHARACTER_ID%type) as
  cursor character_row is select * from RPG_CHARACTERS where in_character_id = CHARACTER_ID
    for update of DELETED_AT nowait ;
begin
  for row in character_row loop
    if(row.DELETED_AT is null) then
      raise_application_error(-20003, 'Caracterul nu este pe lista pentru a fi sters.');
    else
      update RPG_CHARACTERS set DELETED_AT = null where CURRENT OF character_row;
    end if;
  end loop;
end;
/

