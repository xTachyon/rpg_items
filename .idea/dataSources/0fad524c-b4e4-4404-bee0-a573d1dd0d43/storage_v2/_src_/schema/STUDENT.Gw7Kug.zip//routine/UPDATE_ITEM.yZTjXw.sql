create procedure update_item(in_item_id in rpg_items.item_id%type) is
  rand number;
  owner_id number;
  owner_gold number;
  v_price number;
  item_rarity number;
  item_level number;
  item_durability number;
  item_exp_date date;

  type arr_stat_types is table of rpg_stat_types.TYPE_ID%type;
  stat_types arr_stat_types;
  p_stat_num rpg_item_rarity.STATS_NUMBER%type;
  p_num_options number;
  p_option number;
  p_item_utility number;
  p_any_utility number;
  p_item_type number;

  p_min number;
  p_max number;
  p_type_name varchar2(200);

begin
    select OWNER_ID,ITEM_RARITY,BASE_LEVEL,MAXIMUM_DURABILITY,EXPIRATION_DATE, ITEM_TYPE
    into owner_id, item_rarity,item_level,item_durability,item_exp_date, p_item_type
    from RPG_ITEMS
    where in_item_id = ITEM_ID;

    select GOLD into owner_gold
    from RPG_CHARACTERS where character_id = owner_id;

    v_price := item_rarity*(item_level + nvl(ceil(trunc(item_exp_date) - sysdate) + 1, 100));
    if(v_price > owner_gold) then
      raise_application_error(-20006,'Nu aveti '|| v_price ||' gold');
    else
      update RPG_CHARACTERS set GOLD = GOLD - v_price where owner_id = CHARACTER_ID;
    end if;

    if(DBMS_RANDOM.value(1, 100) > item_level / 2) then

      rand := DBMS_RANDOM.value(1, 10);
      if(floor(item_level + rand) <= 100) then
        item_level := floor(item_level + rand);
      else
        item_level := 100;
      end if;

      rand := DBMS_RANDOM.value(0, 3);
      if(floor(item_rarity + rand) <= 4) then
        item_rarity := floor(item_rarity + rand);
      else
        item_rarity := 4;
      end if;

      item_durability := 10 * (item_level + trunc(DBMS_RANDOM.value(1,10)));

      if ( item_exp_date is not null and DBMS_RANDOM.value(0,1) <= 0.9 ) then
        item_exp_date := sysdate + trunc(DBMS_RANDOM.value(1,31));
      else
        item_exp_date := null;
      end if;

      update RPG_ITEMS set BASE_LEVEL = item_level, ITEM_RARITY = item_rarity, CURRENT_DURABILITY = item_durability,
                           MAXIMUM_DURABILITY = item_durability, EXPIRATION_DATE = item_exp_date
           where ITEM_ID = in_item_id;

      select UTILITY_ID into p_item_utility from RPG_ITEM_TYPES where p_item_type = TYPE_ID;
      select UTILITY_ID into p_any_utility from RPG_ITEM_UTILITIES where UTILITY_NAME = 'any';
      if ( p_item_utility = p_any_utility) then
        select TYPE_ID
        bulk collect into stat_types
        from RPG_STAT_TYPES;
      else
        select TYPE_ID
        bulk collect into stat_types
        from RPG_STAT_TYPES
        where p_item_utility = UTILITY_ID;
      end if;

      delete from RPG_ITEM_STATS where in_item_id = ITEM_ID;
      DBMS_OUTPUT.PUT_LINE(item_rarity);
      select STATS_NUMBER into p_stat_num from RPG_ITEM_RARITY where item_rarity = RARITY_ID;

      p_num_options := stat_types.COUNT;
      for i in 0..p_stat_num loop
        p_option := trunc(DBMS_RANDOM.value(1, p_num_options + 1));
        loop
          p_option := mod(p_option + 1, p_num_options + 1);
          if p_option = 0 then
            p_option := 1;
          end if;
          exit when stat_types.exists(p_option);
        end loop;

        select MIN_BASE_VALUE, MAX_BASE_VALUE, NAME into p_min , p_max, p_type_name
        from RPG_STAT_TYPES
        where p_option = TYPE_ID;

        if p_type_name in ('attack damage', 'critical damage', 'armor breaking damage', 'armor','health') then
          insert into rpg_item_stats values (in_item_id,p_option,item_level*round(DBMS_RANDOM.value(p_min,p_max),2));
        else
          insert into rpg_item_stats values (in_item_id,p_option,round(DBMS_RANDOM.value(p_min,p_max),2));
        end if;

        stat_types.delete(p_option);
      end loop;
    else
      delete from RPG_ITEMS where ITEM_ID = in_item_id;
      commit ;
      raise_application_error(-20006,'Itemul a fost distrus in timp ce era imbunatatit');
    end if;
end;
/

