create procedure generate_characters is
  cursor c is select USER_ID from RPG_USERS;

  number_characters number;
  name varchar2(200);
  character_level number;
  gold number;
BEGIN
  for row in c loop
    number_characters := DBMS_RANDOM.value(2, 7);
    for i in 0..number_characters loop
      name := generate_random_string(DBMS_RANDOM.value(15, 20));
      character_level := DBMS_RANDOM.value(1, 100);
      gold := DBMS_RANDOM.value(1, 342512);

      insert into RPG_CHARACTERS
      values(RPG_CHARACTERS_SEQ.nextval, row.USER_ID, name, character_level, gold, null);
    end loop;
  end loop;
END;
/

