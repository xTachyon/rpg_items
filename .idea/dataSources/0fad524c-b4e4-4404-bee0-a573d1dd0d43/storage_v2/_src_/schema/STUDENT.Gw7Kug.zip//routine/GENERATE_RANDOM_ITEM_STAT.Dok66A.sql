create procedure generate_random_item_stat(p_item_id in number, p_item_type in number) as
  p_item_utility number;
  p_any_utility number;
  p_num_options number;
  p_option number;
  p_stat_type_id number;

  p_min number;
  p_max number;
begin
  select UTILITY_ID into p_item_utility from RPG_ITEM_TYPES where p_item_type = TYPE_ID;
  select UTILITY_ID into p_any_utility from RPG_ITEM_UTILITIES where UTILITY_NAME = 'any';
  if ( p_item_utility = p_any_utility) then
    select count(*) into p_num_options
    from rpg_stat_types;

    p_option := trunc(DBMS_RANDOM.value(1,p_num_options + 1));

    select TYPE_ID,MIN_BASE_VALUE, MAX_BASE_VALUE into p_stat_type_id, p_min, p_max
    from (
      select i.*, ROWNUM as R
      from (select * from rpg_stat_types) i
      )
    where R = p_option;
  else
    select count(*) into p_num_options
    from rpg_stat_types
    where p_item_utility = UTILITY_ID;
    p_option := trunc(DBMS_RANDOM.value(1,p_num_options + 1));

    select TYPE_ID,MIN_BASE_VALUE, MAX_BASE_VALUE into p_stat_type_id, p_min, p_max
    from (
      select i.*, ROWNUM as R
      from (select * from rpg_stat_types where p_item_utility = UTILITY_ID) i
      )
    where R = p_option;
  end if;
  insert into rpg_item_stats values (p_item_id,p_stat_type_id,round(DBMS_RANDOM.value(p_min,p_max),2));
end;
/

