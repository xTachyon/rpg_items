create function generate_random_string(string_length number) return varchar2 as
  letters_numbers varchar2(200) := 'abcdefghijklmnopqrstuvwxyz';

  result varchar2(200);
BEGIN
  result := '';

  for i in 1..string_length loop
    result := result || substr(letters_numbers, DBMS_RANDOM.value(1, length(letters_numbers)), 1);
  end loop;

  return result;
END;
/

