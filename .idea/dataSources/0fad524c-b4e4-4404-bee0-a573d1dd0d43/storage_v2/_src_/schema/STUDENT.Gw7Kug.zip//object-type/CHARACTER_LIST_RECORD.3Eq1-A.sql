create type character_list_record is object (
  character_id int,
  character_name varchar2(20),
  character_level int,
  character_delete_timer varchar2(20)
)
/

