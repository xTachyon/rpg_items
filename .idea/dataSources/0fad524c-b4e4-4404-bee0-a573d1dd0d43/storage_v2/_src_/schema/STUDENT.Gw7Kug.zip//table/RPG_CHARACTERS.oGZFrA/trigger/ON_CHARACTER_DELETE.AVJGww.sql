create trigger ON_CHARACTER_DELETE
  before delete
  on RPG_CHARACTERS
  for each row
begin
    delete from RPG_ITEMS where RPG_ITEMS.OWNER_ID = :OLD.CHARACTER_ID;
  end;
/

