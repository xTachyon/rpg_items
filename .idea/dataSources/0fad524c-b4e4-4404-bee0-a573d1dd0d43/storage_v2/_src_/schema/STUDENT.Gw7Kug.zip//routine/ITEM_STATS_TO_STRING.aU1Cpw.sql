create function item_stats_to_string(in_item_id in  rpg_items.item_id%type) return varchar2 is
  cursor stats is select * from RPG_STATS_VIEW where ITEM_ID = in_item_id;
  return_string VARCHAR2(2000);
begin
  select UTILITY_NAME into return_string
    from RPG_ITEMS items join RPG_ITEM_TYPES item_types on items.ITEM_TYPE = item_types.TYPE_ID
                         join RPG_ITEM_UTILITIES item_utilities on item_types.UTILITY_ID = item_utilities.UTILITY_ID
    where ITEM_ID = in_item_id;
    return_string := return_string || chr(13)||chr(10);
  for stat in stats loop
    return_string := return_string ||' ' || stat.NAME || ': ' || stat.VALUE || chr(13)||chr(10);
  end loop;
  return return_string;
end;
/

