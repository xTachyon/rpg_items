create procedure generate_user is
  username_list arr_varchar2 := arr_varchar2('tachyon', 'ml997', 'lamp');

  username varchar2(200);
  password varchar2(200);
  email varchar2(200);
BEGIN
  username := generate_random_string(DBMS_RANDOM.value(15, 20));
  password := generate_random_string(DBMS_RANDOM.value(15, 20));
  email := generate_email();

  insert into RPG_USERS
  values (rpg_users_seq.nextval, username, password, email);
END;
/

